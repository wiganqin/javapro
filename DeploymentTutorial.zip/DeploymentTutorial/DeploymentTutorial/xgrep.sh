#!/bin/bash

java -cp dist/AnotherGrep.jar anothergrep.xGrep
